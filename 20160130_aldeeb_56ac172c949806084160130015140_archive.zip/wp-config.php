<?php // Modified for Arabic by Rasheed Bydousi

/** إعدادات برنامج ووردبريس المعرب **/

// ** إعدادات قاعدة البيانات - ينمكنك الحصول على هذه المعلومات من مستضيفك ** //
/** اسم قاعدة بيانات ووردبريس */
define('DB_NAME', 'basioni1_contractor');

/** اسم المستخدم لقاعدة البيانات */
define('DB_USER', 'basioni1_admin');

/** كلمة المرور لقاعدة البيانات */
define('DB_PASSWORD', 'admin');

/** عنوان خادم قاعدة البيانات */
define('DB_HOST', 'localhost');

/** ترميز قاعدة البيانات */
define('DB_CHARSET', 'utf8');

/** مقارنات قاعدة الببيانات (Collation). 
* إذا كنت غير متأكّد أتركها فارغة */
define('DB_COLLATE', 'utf8_unicode_ci');

/**#@+
 * مفاتيح الأمان.
 * استخدم الرابط التالي لتوليد المفتايح {@link https://api.wordpress.org/secret-key/1.1/salt/}
 * @منذ 2.6.0
 */
define('AUTH_KEY',         'S)jT.Y01ybP^Rbz$De8>lJ@r]&GN&@ ]7s6;M8lN%+5s|f.9lxxP1b&wYc1l&de0');
define('SECURE_AUTH_KEY',  '<#Nf%EHT}OV+b-_n&crM$?Memrzq<S|rC&BNtM:p]t$jH&=90)`_(+XZE>TR)%WM');
define('LOGGED_IN_KEY',    'x#pY(cfeNh7hHP<X6fw(kN}XudR>JSn2cSJQm#0ju0}q++Z`B19zfct=`PMSWU1W');
define('NONCE_KEY',        'htGlBQ{-R)q66>sqXhOBx`u#L|?FavTGdig[:,dG.QL<p5OvR<de5+^NYF7~|:}G');
define('AUTH_SALT',        'D8.!ZogGbH`GOm;wnR?]~q4F^:0#`boDB-pgtGv{ClKS0 Umc 2(sm/eMGt4f`=-');
define('SECURE_AUTH_SALT', 'H%t-:c#V h?2_)](s3S{J9R;zQbvQg%I#juWswGjOZ( zK`{yR`F<iA-1p{d5+N.');
define('LOGGED_IN_SALT',   'zCP>@_rnO I?^n~ p;on92$zGGX1p~wi4&?3E4u)B)YVWj>3},xUD!}a ya;[lVC');
define('NONCE_SALT',       '.yG%XNytXw8(UR-*&L>VivzF<A*%KS%L+K5peP,%Y]SCXxDrQr|6+hBGEVAeQ/h-');


/**#@-*/

/**
 * بادئة الجداول في قاعدة البيانات.
 * تستطيع تركيب أكثر من مدونة على نفس قاعدة البيانات إذا أعطيت لكل قاعدة بادئة جداول مختلفة
 * استخدم فقط حروف, أرقام وخطوط سفلية!
 */
$table_prefix  = 'wp_';

/**
 * اللغة الافتراضية المستخدمة في هذه النسخة هي العربية
 * إذا أردت أن تكون لوحة التحكم في مدونتك بالانجليزية قم بحذف الحرفين أدناه وهي الحروف ar
 */
define('WPLANG', 'ar');

/**
 * للمطورين: نظام تشخيص الأخطاء
 * قم بتغيير flase إلى true لتمكين عرض الملاحظات أثناء التطوير
 */
define('WP_DEBUG', false);

/* هذا هو المطلوب! توقف عن التعديل. نتمنى لك التوفيق في موقعك! */

/** المسار المطلق لمجلد ووردبريس. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');