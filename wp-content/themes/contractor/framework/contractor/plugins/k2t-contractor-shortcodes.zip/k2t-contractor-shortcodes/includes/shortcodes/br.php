<?php
/**
 * Shortcode break.
 *
 * @since  1.0
 * @author K2T Team
 * @link   http://www.kingkongthemes.com
 */

if ( ! function_exists( 'k2t_br_shortcode' ) ) {
	function k2t_br_shortcode( $atts, $content = null ) {
		return '<br />';
	}
}
